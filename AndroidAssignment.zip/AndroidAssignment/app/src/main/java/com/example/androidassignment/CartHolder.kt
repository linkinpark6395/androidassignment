package com.example.androidassignment

object CartHolder {
    val cart = Cart()
}
